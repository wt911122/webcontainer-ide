import { Flex } from 'antd'

export default Flex;