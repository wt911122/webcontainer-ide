import { Table } from 'antd'
const { Column } = Table;

export default Column;