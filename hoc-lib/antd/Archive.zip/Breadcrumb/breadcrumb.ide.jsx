export default function (props) {
    return ( 
    <div {...props}>
        面包屑占位
    </div>)
}